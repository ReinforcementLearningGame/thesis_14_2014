package org.ouc.gameplay;




//import org.rlgame.common.*;
import org.ouc.mrlgame.Settings;


import android.util.Log;

public class HumanPlayer {//implements IPlayer{   There is a major difference in the approach of human player and machine 
	private int id; //id stands for the turn
	private int playerType;
	private int turn;
	private StringBuffer movesLog;
	public String lastmove;
  
public HumanPlayer(int ident) {
		this.id = ident;
		this.turn = ident;
		this.movesLog = new StringBuffer();
		this.playerType =  Settings.HUMAN_PLAYER;
		this.lastmove = "";
		}

	public int getId() {
		return id;
	}

	public int getPlayerType() {
		return playerType;
	}

	public StringBuffer getMovesLog() {
		return movesLog;
	}

	// Human will not pick a move because there no where to pick a move for
	public void pickMove(GameState passedGameState) {
		
	}
	
	public void pickMove(GameState passedGameState, int FromX,int FromY, int ToX, int ToY){	
		//this function must "translate" the ToX, ToY, FromX, FromY and any other information needed
		//into Pawn chosenPawn, Square targetSquare
		
		Square targetSquare = (Square) passedGameState.getSquareByCoordinates(ToX, ToY); // The square to go
		Square fromSquare = (Square) passedGameState.getSquareByCoordinates(FromX, FromY); // The square where i come from
		
		System.out.println("now will call the getWhitePawnFromCoords with ToX= "+ ToX +" - ToY= " + ToY+ " - FromX= " + FromX + " - FromY= " + FromY);
		Pawn chosenPawn = getWhitePawnFromCoords (passedGameState,  FromX, FromY); //get the pawn in selected Coords
		
		if (chosenPawn != null){ 	//if there is a pawn in the selected square
		this.playSelectedMove(chosenPawn, targetSquare, passedGameState);
		this.lastmove = FromX + "," + FromY + " -> " + ToX + "," + ToY; 
		}
		
	}	
	// human player MUST play the selected Move of the human player like any other player
	private void playSelectedMove(Pawn chosenPawn, Square targetSquare, GameState passedGameState) {
		
		String movement = "" + chosenPawn.getPosition().getXCoord() + ","
				+ chosenPawn.getPosition().getYCoord() + "->" 
				+ targetSquare.getXCoord() + ","
				+ targetSquare.getYCoord();// + "->" + 0.0; i don' t understand 0.0 ?????
		Log.w(movement, "playSelectedMove of Human Player");

		// move the pawn
		chosenPawn.movePawn(chosenPawn.getPosition(), targetSquare);
	
		// check for dead pawns
		passedGameState.refreshGameState();

		//TODO check for validity
		passedGameState.pawnsToBinaryArray();

		movement += passedGameState.getPositionOfDeletedPawns();
		
		addMoveLog(movement);
		
		passedGameState.setPositionOfDeletedPawns("");
	}	
	
	public void finishGameSession() {
		
	}
	
	public void addMoveLog(String s) {
		movesLog.append(s);
		movesLog.append("\n");
	}
	
	
	//Will scan all Pawn and return the pawn that much the criteria for the white player
	//all pawns are 10 for white player
	Pawn getWhitePawnFromCoords (GameState passedGameState, int FromX, int FromY){
		
		Pawn CurrentWhitePawns[] = passedGameState.getWhitePawns(); //get the position of all white pawns
		//Pawn CurrentBlackPawns[] = passedGameState.getBlackPawns(); //get the position of all black pawns
		Pawn PawnToReturn = null;  //if no pawn is found return null pawn
		
		// �������: �� � ���� ����� ��� ���� 0,0 ��� �������� ����� ������ �� ���������� �� ��������� ���� ������
		//for (int i = 0;i<=9;i++){
		//	if 	(CurrentWhitePawns[i].position.getXCoord() == FromX && CurrentWhitePawns[i].position.getYCoord() == FromY) {	
		//		PawnToReturn = CurrentWhitePawns[i];
		//		//System.out.println("In the getWhitePawnFromCoords -> Found the white pawn in Coords X,Y "+ FromX + " - " + FromY);
		//	}
		//}
		
		//26/4/2014 changed for with while for 0,0 postition will now return the first pawn.
		int i=0;
		boolean done=false;
		
		while (i<=9 && done == false){
			if 	(CurrentWhitePawns[i].position.getXCoord() == FromX && CurrentWhitePawns[i].position.getYCoord() == FromY) {	
				PawnToReturn = CurrentWhitePawns[i];
				System.out.println("In the getWhitePawnFromCoords -> Found the white pawn in Coords X,Y "+ FromX + " - " + FromY);
				done = true;
			}else {
				i++;
			}
		}
						
		return PawnToReturn;
	
	}
	//will return true if there is a pawn in the Coords X,Y else will return false
	boolean isThereAWhitePawn (GameState passedGameState, int X, int Y){
		
		Pawn thisPawn = getWhitePawnFromCoords (passedGameState,  X, Y); 
		
		if (thisPawn != null){ 	//if there is a pawn in the selected square
			return true;
		}else {
			return false;
		}
		
	}
	
	
  

}
