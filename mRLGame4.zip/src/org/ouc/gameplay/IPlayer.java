package org.ouc.gameplay;

public interface  IPlayer {

	public int getId();
	public int getPlayerType();

	public StringBuffer getMovesLog();
	public String getlastmove();

	public void pickMove(GameState passedGameState);
	public void finishGameSession();
	public void addMoveLog(String s);

}