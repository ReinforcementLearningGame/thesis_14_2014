package org.ouc.mrlgame;

import org.ouc.gameplay.GameState;

import android.util.Log;

//Added by Efthymios Stamatis.
//This class will have the functions to connect GameState <---> GameStateUI 
public class GameStateUI implements Common {
		int visualGameBoard[][];
		boolean selecting;   //will be true if the user is selecting
		boolean selectingFromBase; //will be true if the user is selecting from base
		boolean aPawnIsMoved;
		int BoardTop; //in pixels the top of the board
		int BoardLeft; //in pixels the left of the board
		int BoardSize;  // in pixels the size (it is square) of the board
		int BoardBottom;
		int BoardRight;
		int selectedForMoveX; //will hold the position of a pawn all ready marked for moving
		int selectedForMoveY;
		int pawnselcolor; // will hold the color of the pawn selected
		int selectedX;  //will hold the X currently selected
		int selectedY;  //will hold the Y currently selected
		int CurrentState; //will hold the current state of the UI
		String infotext; //will hold the current information message
		
	
	public GameStateUI (GameState currentGameState){   //constructor
		//int visualGameBoard[][]= new int[8][8]; //this is a visualized game Board
		selecting = false;
		selectingFromBase = false;
		aPawnIsMoved = false;
		selectedX=-1;
		selectedY=-1;
		selectedForMoveX=-1;
		selectedForMoveY=-1;
		pawnselcolor=-1;
		CurrentState = 0;  //the initial current state is the 0
		infotext = "";
		
	}
	//call this any time you need to update the paws places from the currentGameState
	public void PutGameStateToGameStateUI (GameState currentGameState){
		visualGameBoard = currentGameState.getVisualGameBoard();  //get the pawns places
	}
	
	public void checkHumanPlayerSelection(int x, int y){
				
		//IF THE SELECTION IS IN THE GAME BOARD ****************************************************************************
		if (isSelectionInBoard(x,y)){  // check if the touch is inside the board
			  Log.i("checkHumanPlayerSelection","The user have selected inside the board");
			  Log.i("checkHumanPlayerSelection","CurrentState= "+CurrentState );
			  selectedX = selectedXCoord(x);
			  Log.i("selectedX","="+selectedX); //log this
			  selectedY = selectedYCoord(y);   //change pixels to board place y
			  Log.i("selectedY","="+selectedY); //log this
		
			//The user have selected the white Base then set the selectedX and selectedY to 0
			  //because all paws of the white base are in 0,0 place
			  if (isSelectionInWhiteBase(selectedX, selectedY)) {  
				  Log.i("checkHumanPlayerSelection","The user has selected the white Base");
				  selectedX=0;
				  selectedY=0;
				  Log.i("selectedX","="+selectedX); //log this
				  Log.i("selectedY","="+selectedY); //log this
			  }  
			  
			  
			  //INITIALE STATE 0
			  if (CurrentState==0){
				  
				  
				  if (squareHaveAWhitePawn(selectedX,selectedY)){
					  Log.i("checkHumanPlayerSelection","The square have a white pawn, Turn the pawn to red!, CurrentState=1");
					  CurrentState=1;
					  squareMadeRed(selectedX,selectedY);
					  selectedForMoveX=selectedX;
					  selectedForMoveY=selectedY;
			
				  }
			  
			  
			  //SECOND PHASE 1,0 USER HAVE SELECTED A PAWN TO MOVE	  
			  } else if (CurrentState==1 ){
				  Log.i("checkHumanPlayerSelection","The user allready have selected a pawn for moving, user must select where to.");
				 
				  if (isSelectionInWhiteBase(selectedX, selectedY)) {  //if selected the white base cancel the move
					  Log.i("checkHumanPlayerSelection","The user has selected the white Base cancel selection");
					  squareMadeWhite(selectedForMoveX,selectedForMoveY);
					  CurrentState=0;  //return to the previous state 
				  } else if (isTheSquareFree(selectedX,selectedY)==false){
					  Log.i("checkHumanPlayerSelection","The user has selected a not free square");
					  squareMadeWhite(selectedForMoveX,selectedForMoveY);
					  CurrentState=0;  //return to the previous state 
				  } 
					  else if (isThisAValidMoveForHumanPlayer(selectedForMoveX,selectedForMoveY,selectedX,selectedY)){
					  Log.i("checkHumanPlayerSelection","This is a valid move for the human player");
					  CurrentState=2;
		
				  }
				  
			  }
			  
		// THE USER HAVE SELECTED OUTSIDE OF THE BOARD RESET THE STATES
		}else {
			//If the state was the initial the do nothing just log the touch
			if (CurrentState ==0 ){
				Log.i("checkHumanPlayerSelection","User touch outside of the board. CurrentState= " + CurrentState);
			}else if (CurrentState==1){
			// the user have selected a pawn and now he is selecting outside of the board so cancel the move
				Log.i("checkHumanPlayerSelection","User touch outside of the board -> Cancel the move. CurrentState= " + CurrentState );
				CurrentState=0;
		
				squareMadeWhite(selectedForMoveX,selectedForMoveY);
			}
			
			CurrentState=0;

		}
			
	}
	
	
	
	
	//will return true if the move for the human player is valid based only to the VisualGameBoard
	boolean isThisAValidMoveForHumanPlayer(int FromX,int FromY, int ToX, int ToY){
		
		boolean isvalid=false;
		
		if (FromX==ToX && FromY==ToY){ //if the from and to is the same don't do anything
			isvalid= false;
		}else{
		
			if (FromX<=1 && FromY<=1){  //the move will be made from the base
				if (isSelectionInWhiteBase(ToX,ToY)){  // he is moving from base to base so return false
					isvalid= false;
				}else if ((ToX == 2 && ToY<=1) || (ToY==2 && ToX <=1)){ //this is the only valid places when moving from base
					if (isTheSquareFree(ToX,ToY)){ //if the square if free
						isvalid= true;
					}	
				}else {
					isvalid= false;
				}
			}else if(!isSelectionInWhiteBase(FromX,FromY)){ //the move will be made outside of the white base
				Log.i("isthisavalidmoveforhumanplayer", "the move will be made outside of the white base");
				if (isSelectionInWhiteBase(ToX,ToY)){  // he is moving from outside of the base to the base so return false
					isvalid= false;
				} else if(FromX<FromY && ((ToX==FromX && ToY==FromY+1) || (ToX==FromX+1 && ToY==FromY) || (ToX==FromX-1 && ToY==FromY))){ //epano apo thn kyria diagonio
						Log.i("isthisavalidmoveforhumanplayer", "Above the main diagonal");
						isvalid= true;
				} else if(FromX>FromY && ((ToX==FromX && ToY==FromY+1) || (ToX==FromX && ToY==FromY-1) || (ToX==FromX+1 && ToY==FromY))){ //kato apo thn kyria diagoneio
						Log.i("isthisavalidmoveforhumanplayer", "below the main diagonal");	
						isvalid= true;
				} else if (FromX==FromY && ((ToX==FromX && ToY==FromY+1) || (ToX==FromX && ToY==FromY-1) || (ToX==FromX-1 && ToY==FromY) || (ToX==FromX+1 && ToY==FromY))){ // epano sthn kuria diagoneio
						Log.i("isthisavalidmoveforhumanplayer", "On the main diagonal");	
						isvalid = true;
				}else{
					isvalid= false;
				}
			}else{
				isvalid= false;
			}
		}
		if (isvalid){
		Log.i("isthisavalidmoveforhumanplayer", "Valid FromX= " + FromX + "FromY= " + FromY +  "ToX= " + ToX + "ToY= " + ToY);
		} else {
		Log.i("isthisavalidmoveforhumanplayer", "Not Valid FromX= " + FromX + "FromY= " + FromY +  "ToX= " + ToX + "ToY= " + ToY);	
		}
		
		
		return isvalid;
	}
		
	boolean isTheSquareFree (int X,int Y){
		if (visualGameBoard[X][Y]==0){
			return true;
		} else {
			return false;
		}
	}
		
	int selectedXCoord(int x) { //convert pixels in XCoord on the board, x is in pixels
		  return (x - BoardLeft) / 40;  //change pixels to board place x  
	 }	
	
	int selectedYCoord(int y) { //convert pixels in XCoord on the board, y is in pixels
		  return (Math.abs(y - BoardTop - BoardSize)) / 40;  //change pixels to board place x  
	  }
	
	boolean isSelectionInWhiteBase(int x, int y){ //check if the user have selected in the white base, x and y in pixels
		  if (x<=1 && y<=1){
			  return true;
		  } else {
			  return false;
		  }
	  }
	
	 boolean isSelectionInBlackBase(int x, int y){ //check if the user have selected in the white base, x and y in pixels
		  if (x>=6 && y>=6){
			  return true;
		  } else {
			  return false;
		  }
	  }
	
	 boolean isSelectionInBoard(int x, int y){  //check if the user have selected in the board or outside
		  if (x>=BoardLeft && x<=BoardLeft+BoardSize && y>=BoardTop && y<=BoardTop+BoardSize) {
			  return true;
		  } else {
			  return false;
		  }
	  }
	 
	 boolean squareHaveAWhitePawn(int x, int y){ // check if the square have a white pawn
		 if (visualGameBoard[x][y]==1){
				return true;
			} else {
				return false;
			}
	 }
	
	 void squareMadeRed(int x, int y){  //set the pawn to the coords x,y to red
		 visualGameBoard[x][y]=3;		 
	 }
	 
	 void squareMadeWhite(int x, int y){  //set the pawn to the coords x,y to red
		 visualGameBoard[x][y]=1;		 
	 }
	 void squareMadeEmpty(int x, int y){  //set the pawn to the coords x,y to red
		 visualGameBoard[x][y]=0;		 
	 }
}
