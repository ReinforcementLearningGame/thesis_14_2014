package org.ouc.mrlgame;

import java.util.Random;
import java.util.StringTokenizer;

import org.ouc.gameplay.GameState;
import org.ouc.gameplay.HumanPlayer;
import org.ouc.gameplay.IPlayer;
import org.ouc.gameplay.MMPlayer;
import org.ouc.gameplay.Pawn;
import org.ouc.gameplay.RLPlayer;
import org.ouc.gameplay.RandomPlayer;
import org.ouc.mrlgame.GameStateUI;
import org.ouc.mrlgame.Settings;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

public class GameView extends View implements Common{
	
	//MOVED FROM SPIEL CLASS
	private GameState currentGameState;
	private GameStateUI currentGameStateUI;
	private HumanPlayer whitePlayer;  //The human player is not an Iplayer
	private IPlayer blackPlayer; 
	//-----------------------------------------------
	//private float mScaleFactor = 1.f;   //set the scale factor to 1

	
		// Set the colors to be used
		Paint BlackPaint = new Paint();
		Paint WhitePaint = new Paint();
		Paint RedPaint = new Paint();
		Paint GrayPaint = new Paint();
				
		
		public int CHeight;   //will hold the canvas height in pixels
		public int CWidth;   // will hold the canvas width in pixels
		public Canvas canvas;  // The canvas that will draw
		public String GameResult[] = new String[1];
		
	
		public int winner=0;
		//public int counter=1;
		public boolean humaninteraction=true; //will not let the black eg computer play if this is true
		public int turn=1; // 1=human, 2=computer
	
	public GameView(Context context) {
		super(context);
		
		
		//initialize a new game -> Copy from original Spiel Class
		Pawn [] whitePawn = new Pawn[Settings.NUMOFPAWNS];
		Pawn [] blackPawn = new Pawn[Settings.NUMOFPAWNS];

		for (int i = 0; i < Settings.NUMOFPAWNS; i++) {
			whitePawn[i] = new Pawn(i, true);
			blackPawn[i] = new Pawn(i, false);
		}
		
		
		currentGameState = new GameState(whitePawn, blackPawn);  //initialize a new game
		currentGameStateUI = new GameStateUI(currentGameState );  //initialize the visual part of the Game
		currentGameStateUI.PutGameStateToGameStateUI(currentGameState); //update the visual part of the Game
		
		whitePlayer = new HumanPlayer(Settings.WHITE_PLAYER); //create the human player for the white player
		
		// create the selected type of computer player
		if (Settings.PLAYER_B_MODE == Settings.RL_PLAYER){
			blackPlayer = new RLPlayer(Settings.BLACK_PLAYER);
			Log.i("GameView","Created new RL_PLAYER");
			
		} else if (Settings.PLAYER_B_MODE == Settings.MM_PLAYER){
			blackPlayer = new MMPlayer(Settings.BLACK_PLAYER, Settings.PLAYER_B_PLIES, Settings.WHITE_PLAYER);
			Log.i("GameView","Created new MM_PLAYER");
			
		} else {
			blackPlayer = new RandomPlayer(Settings.RANDOM_PLAYER);
			Log.i("GameView","Created new RANDOM_PLAYER");
			
		}
		
		
		//--------------------------------------------------------------------------------------------
		
		
	}
	
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        // 
		//int height;
		//int width;
		
        //width = MeasureSpec.getSize(widthMeasureSpec);
        //height = MeasureSpec.getSize(heightMeasureSpec);
        //height = CHeight;
        
        //Log.i("GameView onMeaure width/height", "w= "+width+" h= "+height);
        
       // if (CHeight > 480) {
       // 	 height = CHeight; 
        //}
        
        //setMeasuredDimension(width, height);


		// new code from internet 13/4/2014 ----------------------------------------------------------
		
		
		int desiredWidth = 480;
	    int desiredHeight = 480;

	    int widthMode = MeasureSpec.getMode(widthMeasureSpec);
	    int widthSize = MeasureSpec.getSize(widthMeasureSpec);
	    int heightMode = MeasureSpec.getMode(heightMeasureSpec);
	    int heightSize = MeasureSpec.getSize(heightMeasureSpec);
	    Log.i("GameView onMeaure width/height", "w= "+ widthSize +" h= "+ heightSize);

	    int width;
	    int height;

	    //Measure Width
	    if (widthMode == MeasureSpec.EXACTLY) {
	        //Must be this size
	        width = widthSize;
	    } else if (widthMode == MeasureSpec.AT_MOST) {
	        //Can't be bigger than...
	        width = Math.min(desiredWidth, widthSize);
	    } else {
	        //Be whatever you want
	        width = desiredWidth;
	    }

	    //Measure Height
	    if (heightMode == MeasureSpec.EXACTLY) {
	        //Must be this size
	        height = heightSize;
	    } else if (heightMode == MeasureSpec.AT_MOST) {
	        //Can't be bigger than...
	        height = Math.min(desiredHeight, heightSize);
	    } else {
	        //Be whatever you want
	        height = desiredHeight;
	    }

	    //MUST CALL THIS
	    setMeasuredDimension(width, height);
		
	
	}
	
	
	
	
	//@Override
	public void onDraw(final Canvas canvas) {
	
		String dialogMessage;
		
		if (currentGameStateUI.CurrentState!=5){  //The is not over -> draw
		
		//set the colors
		setColors();
				
		//set canvas background Color		
		canvas.drawColor(Color.LTGRAY);
		
		//From this point the GAME is played when the user touches the screen. Then the currentGameStateUI.VisualGameBoard array is updated
		//and all other gameplay is done and then the method invalidate() is called that invokes the onDraw again and
		//everything is drawn again and visualize the changes on the game.
		
		//This must be done here because outside of the onDraw method the first time there is no canvas to get the size of
		//If you try to do this outside of the onDraw a fatal error is made in the MainActivity.java !!!
		CHeight = canvas.getHeight();  //get the canvas height
		CWidth = canvas.getWidth(); //get the canvas width
		
		//canvas.scale does not fuction the way i wanted
		//if ((CHeight < 480) || (CWidth < 480)) {
		//	int min;
		//	if (CHeight < CWidth){
		//		min = CHeight;
		//	}else {
		//		min = CWidth;
		//	}
		//	mScaleFactor = min / 480.F;
		//}	
				
		//canvas.scale(mScaleFactor, mScaleFactor);
		
		//Log.i("GameView","mScaleFactor = "  + mScaleFactor);
		Log.i("GameView","Canvas Height = " + CHeight);
		Log.i("GameView","Canvas Width = " + CWidth);
		currentGameStateUI.BoardSize = DIMBOARD * 40;
		currentGameStateUI.BoardLeft = CWidth /2 - currentGameStateUI.BoardSize /2 ;  //The left of the Board
		//currentGameStateUI.BoardTop = CHeight / 2 - currentGameStateUI.BoardSize /2;  //The Top of The Board
		currentGameStateUI.BoardTop = 60;
		currentGameStateUI.BoardBottom = currentGameStateUI.BoardTop + currentGameStateUI.BoardSize;
		currentGameStateUI.BoardRight = currentGameStateUI.BoardLeft + currentGameStateUI.BoardSize;
		
		//------------------------------------------------------------------------------------------------------------------
		
		
		
		
		if (currentGameStateUI.CurrentState!=1){   //this is done so if the user is selecting not to update the currentGameStateUI so to display the red ones
			Log.i("GameView","Updating the CurrentGameStateUI from CurrentGameState");
			
        	currentGameState.refreshGameState();
        	currentGameState.synchronizeGameBoard();
			
			currentGameState.printGameBoard();
			currentGameState.printPawns(1);
			currentGameState.printPawns(2);
			if (currentGameState.isFinal()){ //the game have finished	
				winner = currentGameState.getWinner();
				Log.i("GameView","winner = " + winner);	
				Log.i("GameView","GAME OVER !!!");
				
				if (winner==1) { 
					dialogMessage="Winner: White Player";
				}else {
					dialogMessage="Winner: Black Player";
				}
				
				currentGameStateUI.CurrentState=5; //this is the final state. 
				
				//The game is over 
				//call finish game on each player
	    		//aka store neural network weights info
				
				
				new AlertDialog.Builder(getContext())
			    .setTitle("Game Over")
			    .setMessage(dialogMessage)
			    
			    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
			        public void onClick(DialogInterface dialog, int which) { 
			            // continue with delete
			        }
			     })
			     .show();
				
				//The game is over 
				//call finish game on each player
	    		//aka store neural network weights info
				Log.i("GameView","finishGameSession");
				whitePlayer.finishGameSession();
				blackPlayer.finishGameSession();
				storeGameMovesAndStats();
			}
			currentGameStateUI.PutGameStateToGameStateUI(currentGameState); //update the visual part of the Game
		}
		drawboard(canvas);   //draw the lines of the board
		drawpawns(canvas);   //draw the pawns state
		
		if (currentGameStateUI.CurrentState==3){
			currentGameStateUI.infotext="Computer pick move";
			Log.i("GameView","CurrentState = 3"); //Log this
      	 
			
			currentGameStateUI.CurrentState=4;
			forceLayout();
			draw(canvas);
			invalidate();
		}
				
		if (currentGameStateUI.CurrentState==4) {
			
			blackPlayer.pickMove(currentGameState);  //black player pick a move 
			currentGameStateUI.CurrentState = 0;
			
    		turn=1;   //now it is human turn to play
    		
    		drawboard(canvas);   //draw the lines of the board
    		drawpawns(canvas);   //draw the pawns state
    		invalidate();
		}

		}	

	}

 //This function draws the pawn places based on the currentGameStateUI.visualGameBoard and not the actual Game State
// will draw with WhitePaint the white pawns
// with BlackPaint the black Pawns
// and with RedPaint the currently selected pawn ready to be moved
 void drawpawns(Canvas c) {
	  
	  if (currentGameStateUI.selectingFromBase) {
		  currentGameStateUI.infotext="User is selecting from base";
	
	 } else {
	 for (int i=0;i<=7;i=i+1){
			for (int j=0;j<=7; j=j+1){
				if (currentGameStateUI.visualGameBoard[i][j]==1) {
					c.drawCircle(currentGameStateUI.BoardLeft+i*40+20, currentGameStateUI.BoardBottom-(j+1)*40+20, 18, WhitePaint);
					//c.drawText(String.valueOf(i),currentGameStateUI.BoardLeft+i*40+20,currentGameStateUI.BoardBottom-(j+1)*40+20,BlackPaint);
				} else if (currentGameStateUI.visualGameBoard[i][j]==2) {
					c.drawCircle(currentGameStateUI.BoardLeft+i*40+20, currentGameStateUI.BoardBottom-(j+1)*40+20, 18, BlackPaint);
				} else if (currentGameStateUI.visualGameBoard[i][j]==3){  //it is red and ready to be moved
					c.drawCircle(currentGameStateUI.BoardLeft+i*40+20, currentGameStateUI.BoardBottom-(j+1)*40+20, 18, RedPaint);
					currentGameStateUI.infotext="White Pawn in x= " + currentGameStateUI.selectedX + " y= " + currentGameStateUI.selectedY + " is selected";
			
				}
						
			};
		};
	 };
		showinfogame(c);
	   
  }

  
  void drawboard(Canvas c){  //it draws the lines of the board
	  
	  //draw board Background
	  		c.drawRect(currentGameStateUI.BoardLeft, currentGameStateUI.BoardTop, currentGameStateUI.BoardLeft+currentGameStateUI.BoardSize, currentGameStateUI.BoardTop+currentGameStateUI.BoardSize, GrayPaint);
	  //draw horizontal lines
	  		for (int i=currentGameStateUI.BoardTop;i<=currentGameStateUI.BoardTop+currentGameStateUI.BoardSize;i=i+40){
				c.drawLine(currentGameStateUI.BoardLeft, i, currentGameStateUI.BoardLeft+currentGameStateUI.BoardSize, i, BlackPaint);
			};
		//draw vertical lines
			for (int i=currentGameStateUI.BoardLeft;i<=currentGameStateUI.BoardLeft+currentGameStateUI.BoardSize;i=i+40){
				c.drawLine(i, currentGameStateUI.BoardTop, i, currentGameStateUI.BoardTop+currentGameStateUI.BoardSize, BlackPaint);
			};
		//draw white base down and left
			c.drawRect(currentGameStateUI.BoardLeft, currentGameStateUI.BoardTop+6*40, currentGameStateUI.BoardLeft + 2*40, currentGameStateUI.BoardBottom, WhitePaint);
		//draw white base up and right
			c.drawRect(currentGameStateUI.BoardLeft + 6*40 , currentGameStateUI.BoardTop, currentGameStateUI.BoardLeft +currentGameStateUI.BoardSize, currentGameStateUI.BoardTop+2*40, BlackPaint);
		//draw numbers on lines and cols
			int num=7;
	  		for (int i=currentGameStateUI.BoardTop;i<=currentGameStateUI.BoardTop+currentGameStateUI.BoardSize-40;i=i+40){
				c.drawText("Y"+num,currentGameStateUI.BoardLeft-40,i+20,BlackPaint);
				num--;
			};
			num=0;
			for (int i=currentGameStateUI.BoardLeft;i<=currentGameStateUI.BoardLeft+currentGameStateUI.BoardSize-40;i=i+40){
				c.drawText("X"+num,i+20,currentGameStateUI.BoardTop+currentGameStateUI.BoardSize+20,BlackPaint);
				num++;
			};
  }
  
  // This function handles the user touch event
  @Override
  public boolean onTouchEvent(MotionEvent event) {
      switch (event.getAction()) {
         // case MotionEvent.ACTION_DOWN:
          //case MotionEvent.ACTION_MOVE:
              // Start dragging
             // selecting = true;
              
            //  break;
          case MotionEvent.ACTION_UP:
        	  final int x=(int)event.getX();  //get x in pixel of the touch event
        	  final int y=(int)event.getY();  //get y in pixel of the touch event
        	  Log.i("***********xPos","="+x); //Log this
        	  Log.i("***********yPos","="+y); //Log this
        	  
        	  //Grab from spiel ------------------------------------------      	  
        	         	
        	 
        	// if the the game is not finished and it is white (human) player time to play then 
        	if ((! currentGameState.isFinal()) && turn == 1) { //&& (counter < Settings.MAX_MOVES_COUNTER)) {
        	  //to the white human player must send the pawn to move and where to
        		  
        		currentGameStateUI.checkHumanPlayerSelection(x, y);  //currently all the job is done on this function -> WILL CHANGE THAT
        		
        		
        		
        		  // if a pawn is actually have changed place in the board then move it and in the gamestate
        		if (currentGameStateUI.CurrentState==2) { 
        			//showinfotext("Human pick move " + "From: " + currentGameStateUI.selectedForMoveX + "," + currentGameStateUI.selectedForMoveY + "-> " + currentGameStateUI.selectedX + ","+currentGameStateUI.selectedY,canvas );
        			Log.i("onTouchEvent","if a pawn is actually have changed place in the board then move it and in the gamestate");  
        			whitePlayer.pickMove(currentGameState,currentGameStateUI.selectedForMoveX,currentGameStateUI.selectedForMoveY,currentGameStateUI.selectedX,currentGameStateUI.selectedY );
        			currentGameStateUI.selecting = false; //done with the move 
        			turn=2; //now it is computer turn to play
        			currentGameStateUI.CurrentState = 3; //3 means that a move has been done !!!
        			
    				invalidate();  //Invoke ondraw 
    				}
			 
        	}	
			        	 
        	  invalidate();  //Invoke ondraw 
            break;
      }
      return true;
  }
  
  // display information about the status of the game
  void showinfogame(Canvas c){
	  
	  int whitePawnsLeft = currentGameState.getWhiteRemaining(currentGameState.getWhitePawns());
	  c.drawText("White Paws alive = " + whitePawnsLeft, currentGameStateUI.BoardLeft-50 ,currentGameStateUI.BoardTop - 30 , WhitePaint);
	  int blackPawnsLeft = currentGameState.getBlackRemaining(currentGameState.getBlackPawns());
	  c.drawText("Black Paws alive = " + blackPawnsLeft, currentGameStateUI.BoardLeft + currentGameStateUI.BoardSize - 120  , currentGameStateUI.BoardTop - 30, BlackPaint);
	  c.drawText("Human Played: " + whitePlayer.lastmove, currentGameStateUI.BoardLeft , currentGameStateUI.BoardTop+currentGameStateUI.BoardSize+45, WhitePaint); 
	  
	  if (Settings.PLAYER_B_MODE == Settings.RL_PLAYER){
		  c.drawText("RL Player Played: " + blackPlayer.getlastmove(), currentGameStateUI.BoardLeft , currentGameStateUI.BoardTop+currentGameStateUI.BoardSize+70, BlackPaint);
			
		} else if (Settings.PLAYER_B_MODE == Settings.MM_PLAYER){
			c.drawText("Min-Max Played: " + blackPlayer.getlastmove(), currentGameStateUI.BoardLeft , currentGameStateUI.BoardTop+currentGameStateUI.BoardSize+70, BlackPaint);
			
		} else {
			c.drawText("Random Played: " + blackPlayer.getlastmove(), currentGameStateUI.BoardLeft , currentGameStateUI.BoardTop+currentGameStateUI.BoardSize+70, BlackPaint);
			
		}

  }
  
  // set colors and test size
  void setColors(){
	  
	  	BlackPaint.setColor(Color.rgb(0, 0, 0));
		BlackPaint.setStrokeWidth(3);
		BlackPaint.setTextSize(16); 
			
		WhitePaint.setColor(Color.rgb(255, 255, 255));
		WhitePaint.setStrokeWidth(3);
		WhitePaint.setTextSize(16); 
		
		RedPaint.setColor(Color.rgb(255, 6,6));
		RedPaint.setStrokeWidth(3);	
		
		GrayPaint.setColor(Color.rgb(192,192,192));
		GrayPaint.setStrokeWidth(3);	
	
  }
  // show a small toast message
  public void showMessageToast(String Message){

	  CharSequence text = Message;
	  int duration = Toast.LENGTH_SHORT;
	  Toast toast = Toast.makeText(getContext(), text, duration);
	  toast.show();  
  }
  
  
  //MOVED FROM SPIEL-------------------------------------
  public void storeGameMovesAndStats() {
		
		String wHistory = whitePlayer.getMovesLog().toString(); 
		String bHistory = blackPlayer.getMovesLog().toString(); 
		
		History gameHistory = new History();
		

		StringTokenizer stW = new StringTokenizer(wHistory.replace('\n', ' '));
		StringTokenizer stB = new StringTokenizer(bHistory.replace('\n', ' '));
		String gameMoves = "";
		
		while (stB.hasMoreTokens()) {
			gameMoves += stW.nextToken() + "\t" + stB.nextToken() + "\n";
		}

		// o aspros mporei na exei mia akomi kinisi => check it
		if (stW.hasMoreTokens()) {
			gameMoves += stW.nextToken() + '\n';
		}
		
		gameHistory.writeToFile(gameMoves,
				"_cVSc_" + Settings.DIMBOARD + "_" + Settings.DIMBASE + "_" + Settings.NUMOFPAWNS
						+ "_game_" + Math.abs(new Random().nextInt()), 0, 1);
	}
//-----------------------------------------------------------------------------------------------------
}



