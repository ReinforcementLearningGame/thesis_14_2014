package org.ouc.mrlgame;

import org.ouc.mrlgamewithrllib.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;

public class InstructionActivity extends Activity{

	Button BackButton;
	
	@SuppressWarnings("deprecation")
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.instructions);
	
        BackButton = (Button) findViewById (R.id.back);
        
        WebView wv= (WebView) findViewById(R.id.instructionswebview);
        wv.getSettings().setPluginsEnabled(true);
        WebSettings webSettings = wv.getSettings();
        webSettings.setJavaScriptEnabled(true);
        wv.loadUrl("file:///android_asset/gameinstr.html");
	
        BackButton.setOnClickListener(new View.OnClickListener() {
        	
        	@Override
			public void onClick(View v) {
        		
                finish();
        		        		
        	}
        	
        	
        	
        });
        
        
        
        
	}
}
