package org.ouc.mrlgame;

import org.ouc.mrlgame.GameView;
import org.ouc.mrlgamewithrllib.R;

import android.os.Build;
import android.os.Bundle;
import android.app.Activity;
import android.graphics.Point;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.WindowManager;
import android.widget.ScrollView;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		//added 01/06/2014
		int Measuredwidth = 0;
		int Measuredheight = 0;
		Point size = new Point();
		WindowManager w = getWindowManager();

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2)
		{
		    w.getDefaultDisplay().getSize(size);

		    Measuredwidth = size.x;
		    Measuredheight = size.y;
		}
		else
		{
		    Display d = w.getDefaultDisplay();
		    Measuredwidth = d.getWidth();
		    Measuredheight = d.getHeight();
		}
		Log.i("MainActivity","Measuredwidth = " + Measuredwidth);
		Log.i("MainActivity","Measuredheight = " + Measuredheight);
		////////////////////////////////////////////////////////////
		
		
		if (Measuredheight < 480){
			//Create a Scollview
			//paremvasi 08042014
			ScrollView scrollView = new ScrollView(this);
			scrollView.addView(new GameView(this));
			setContentView(scrollView);
			
		} else {	
		// create a normal view
		setContentView(new GameView(this));  //Set the view to the GameView
		}
	}
		

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
