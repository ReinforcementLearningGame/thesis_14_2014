package org.ouc.mrlgame;


import org.ouc.mrlgamewithrllib.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MenuActivity extends Activity{

	
	Button StartGame;
	Button ShowInstructions;
	RadioButton RLPlayer;
	RadioButton MMPlayer;
	RadioButton RandomPlayer;
	RadioGroup PlayerTypeRadioGroup;
	
	
	 @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.menu);
	        
	        RLPlayer = (RadioButton) findViewById (R.id.rb_RLPlayer);
	        MMPlayer = (RadioButton) findViewById (R.id.rb_MMPlayer);
	        RandomPlayer = (RadioButton) findViewById (R.id.rb_RandomPlayer);
	        PlayerTypeRadioGroup = (RadioGroup) findViewById (R.id.radioComputerPlayer);
	        StartGame = (Button) findViewById (R.id.start);
	        ShowInstructions = (Button) findViewById (R.id.instructionsbutton);
	        
	        
	        RLPlayer.setChecked(true);  //Set RLPlayer as default
	        Settings.PLAYER_B_MODE = Settings.RL_PLAYER; //Set Black Player to RL_PLAYER       
	        
	        Display display = getWindowManager().getDefaultDisplay(); 
	        int width = display.getWidth();  // deprecated
	        int height = display.getHeight();  // deprecated
	        String dialogMessage = "This application runs best on resolution 480X480 or higher.";
	        if ((width < 480 ) || (height < 480)) {
	        	new AlertDialog.Builder(this)
			    .setTitle("Warning")
			    .setMessage(dialogMessage)
			    
			    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
			        public void onClick(DialogInterface dialog, int which) { 
			            // continue with delete
			        }
			     })
			     .show();
	        	
	        	
	        }
	        
	        StartGame.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					int rgid = PlayerTypeRadioGroup.getCheckedRadioButtonId();			
					
					if (rgid == R.id.rb_RLPlayer) {
						Settings.PLAYER_B_MODE = Settings.RL_PLAYER; //Set Black Player to RL_PLAYER 
			        }

			        if (rgid == R.id.rb_MMPlayer) {
			        	Settings.PLAYER_B_MODE = Settings.MM_PLAYER; //Set Black Player to RL_PLAYER 
			        	Settings.PLAYER_B_PLIES = 15;   //the depth for MM_PLAYER
			        }

			        if (rgid == R.id.rb_RandomPlayer) {
			        	Settings.PLAYER_B_MODE = Settings.RANDOM_PLAYER;
			        }
			        
		
					Intent OpenMainActivity = new Intent("org.ouc.mrlgamewithrllib.MAINACTIVITY");
					startActivity(OpenMainActivity);
					
					
				}
			});
	        
	        
	        ShowInstructions.setOnClickListener(new View.OnClickListener() {
	
	        	@Override
				public void onClick(View v) {
	        		
	        		Intent OpenInstructionActivity = new Intent("org.ouc.mrlgamewithrllib.INSTRUCTIONACTIVITY");
					startActivity(OpenInstructionActivity);
	        		
	        		
	        	}
	        	
	        	
	        	
	        });
	 }

}
