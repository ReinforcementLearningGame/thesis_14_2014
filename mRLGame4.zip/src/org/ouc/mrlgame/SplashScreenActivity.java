package org.ouc.mrlgame;



import org.ouc.mrlgamewithrllib.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class SplashScreenActivity  extends Activity {

	 @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.splashscreen);
	        
	        
	        Thread Timer = new Thread(){
				public void run(){
					try {
						sleep(5000);
					}catch (InterruptedException e){
						e.printStackTrace();
					}finally{
						Intent OpenMainMenu = new Intent("org.ouc.mrlgamewithrllib.MENUACTIVITY");
						startActivity(OpenMainMenu);
					}
				}	
			};
			Timer.start();
	        
	        
	        
	    }
	 
	 
	 @Override
		protected void onPause() {
			// TODO Auto-generated method stub
			super.onPause();
			
			//end the Activity
			finish();
		}
	
	
}
